clc;
clear;
close all;

saveDir = '../../../results/Tophat/';
if ~exist(saveDir)
    mkdir(saveDir);
end
imgpath = '../../../data/';
imgDir = dir([imgpath '*.png']);

patch_size = 50;
se=strel('square',patch_size);  % disk Բ�Σ�����

for i=1:length(imgDir)
    fprintf('%d/%d: %s\n', length(imgDir), i, imgDir(i).name);
    img = imread([imgpath imgDir(i).name]);
    if ndims( img ) == 3
        img = squeeze(img(:,:,1));
    end
    img = double(img);
%     img = img./max(max(img));
    
    out = imtophat(img,se);
    imwrite(out./max(max(out)), [saveDir imgDir(i).name]);
%     figure;surf(out)
end

function f2 = tophat1(f1,se)
    f2=imtophat(f1,se);
end